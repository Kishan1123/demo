package com.example.demo.model;

public class LogInModel {
    private String name;
    private String pass;


    public  LogInModel(String name, String pass) {
        this.name = name;
        this.pass = pass;
    }
}
